<html>


<form method="post" action="{{URL :: to ('/submit')}}">
    <input name="name" type="text" placeholder="name">
    <input name="password" type="text" placeholder="password">
    <input name="token" value="{{csrf_token()}}" type="hidden">
    <input type="submit" value="submit">
</form>

@if($errors->any())
    <div>
        <ul>
            @foreach($errors ->all() as $error)
                <li style="color:red">{{$error}}</li>
                @endforeach
        </ul>
    </div>
@endif
{{--{{$data}}--}}
</html>
