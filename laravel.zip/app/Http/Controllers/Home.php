<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Home extends Controller
{
    //
    public function show(Request $request){
//        echo 'Hello Form Controller'.$id;
        $data = $request->method();

//        echo $id;
//        print_r($data);
        return view('index', ["item" => $data]);
    }
    function save(Request $request){
          $validation = $request->validate([
              'name' => 'required | max:5',
              'password' => 'required| min:3'
           ]);
echo 'user';
    }
}
