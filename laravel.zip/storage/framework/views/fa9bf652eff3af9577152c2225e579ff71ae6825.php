<html>


<form method="post" action="<?php echo e(URL :: to ('/submit')); ?>">
    <input name="name" type="text" placeholder="name">
    <input name="password" type="text" placeholder="password">
    <input name="token" value="<?php echo e(csrf_token()); ?>" type="hidden">
    <input type="submit" value="submit">
</form>

<?php if($errors->any()): ?>
    <div>
        <ul>
            <?php $__currentLoopData = $errors ->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li style="color:red"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

</html>
